from models import questions

sample_questions = [
    {
        "course": "ML",
        "difficulty": "easy",
        "question": "What is supervised learning?",
        "options": [
            "Learning with labeled data",
            "Learning without data",
            "Random learning",
            "Manual programming"
        ],
        "answer": "Learning with labeled data"
    },
    {
        "course": "ML",
        "difficulty": "hard",
        "question": "Which algorithm uses gradient descent?",
        "options": [
            "Linear Regression",
            "K-Means",
            "Apriori",
            "KNN"
        ],
        "answer": "Linear Regression"
    },
    {
        "course": "DL",
        "difficulty": "easy",
        "question": "What is a neural network?",
        "options": [
            "Set of algorithms inspired by brain",
            "Database",
            "Compiler",
            "OS"
        ],
        "answer": "Set of algorithms inspired by brain"
    },
    {
        "course": "AI",
        "difficulty": "easy",
        "question": "AI stands for?",
        "options": [
            "Artificial Intelligence",
            "Automated Interface",
            "Advanced Internet",
            "Applied Integration"
        ],
        "answer": "Artificial Intelligence"
    }
]

questions.insert_many(sample_questions)

print("Sample Questions Inserted Successfully!")