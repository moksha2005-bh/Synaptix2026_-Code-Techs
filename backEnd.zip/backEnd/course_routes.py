from flask import Blueprint, jsonify

# The variable name MUST be 'course'
course = Blueprint("course", __name__)

@course.route("/courses", methods=["GET"])
def get_courses():
    return jsonify([
        "ML", "DL", "AI",
        "C", "C++", "Java",
        "Python", "DBMS",
        "SEO", "OOP", "Software Testing"
    ])