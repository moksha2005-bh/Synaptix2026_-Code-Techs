from flask import Flask
from flask_cors import CORS

# Import all route files
from auth_routes import auth
from course_routes import course
from assessment_routes import assessment

app = Flask(__name__)

# Enable CORS (to allow frontend connection)
CORS(app)

# Register all blueprints
app.register_blueprint(auth)
app.register_blueprint(course)
app.register_blueprint(assessment)


# Optional: Home route (to avoid "Not Found")
@app.route("/")
def home():
    return "Adaptive Assessment Backend is Running Successfully!"


if __name__ == "__main__":
    app.run(debug=True, port=5000)