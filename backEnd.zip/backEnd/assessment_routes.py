from flask import Blueprint, request, jsonify
from models import questions, results
import time

assessment = Blueprint("assessment", __name__)

@assessment.route("/get-question/<course>/<difficulty>", methods=["GET"])
def get_question(course, difficulty):
    question = questions.find_one({"course": course, "difficulty": difficulty})
    if question:
        question["_id"] = str(question["_id"])
        return jsonify(question)
    return jsonify({"error": "No question found"}), 404


@assessment.route("/submit", methods=["POST"])
def submit():
    data = request.json

    accuracy = (data["correct"] / data["total"]) * 100
    performance = "Beginner"

    if accuracy > 80:
        performance = "Advanced"
    elif accuracy > 50:
        performance = "Intermediate"

    results.insert_one({
        "email": data["email"],
        "course": data["course"],
        "accuracy": accuracy,
        "correct": data["correct"],
        "incorrect": data["incorrect"],
        "time_taken": data["time_taken"],
        "performance": performance
    })

    return jsonify({
        "accuracy": accuracy,
        "performance": performance
    })