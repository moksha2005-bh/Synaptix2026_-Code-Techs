import { useState } from 'react';
import LandingView from '@/components/LandingView';
import TopicSelector from '@/components/TopicSelector';
import QuizView from '@/components/QuizView';
import ResultsView from '@/components/ResultsView';
import { AdaptiveEngine } from '@/lib/adaptiveEngine';
import { AssessmentResult, Topic } from '@/types/assessment';

type Phase = 'landing' | 'topic-select' | 'quiz' | 'results';

const Index = () => {
  const [phase, setPhase] = useState<Phase>('landing');
  const [results, setResults] = useState<AssessmentResult | null>(null);
  const [selectedTopics, setSelectedTopics] = useState<Topic[]>([]);

  const handleStart = () => setPhase('topic-select');

  const handleTopicsSelected = (topics: Topic[]) => {
    setSelectedTopics(topics);
    setPhase('quiz');
  };

  const handleComplete = (engine: AdaptiveEngine) => {
    setResults(engine.getResults());
    setPhase('results');
  };

  const handleRetake = () => {
    setResults(null);
    setPhase('topic-select');
  };

  return (
    <>
      {phase === 'landing' && <LandingView onStart={handleStart} />}
      {phase === 'topic-select' && <TopicSelector onStart={handleTopicsSelected} />}
      {phase === 'quiz' && <QuizView selectedTopics={selectedTopics} onComplete={handleComplete} />}
      {phase === 'results' && results && <ResultsView results={results} onRetake={handleRetake} />}
    </>
  );
};

export default Index;
