import { Question, Difficulty, Topic, AnswerRecord, AssessmentResult, TopicProfile, DIFFICULTY_VALUE, TOPIC_LABELS } from '@/types/assessment';
import { questionBank } from '@/data/questionBank';

export class AdaptiveEngine {
  private answers: AnswerRecord[] = [];
  private currentDifficulty: Difficulty = 'medium';
  private usedQuestionIds: Set<string> = new Set();
  private topicIndex = 0;
  private topics: Topic[];
  private consecutiveCorrect = 0;
  private consecutiveWrong = 0;
  private difficultyHistory: { question: number; difficulty: number }[] = [];
  private _totalQuestions: number;

  constructor(selectedTopics?: Topic[]) {
    this.topics = selectedTopics && selectedTopics.length > 0
      ? selectedTopics
      : ['algebra', 'geometry', 'calculus', 'statistics', 'logic'];
    this._totalQuestions = Math.max(5, Math.min(15, this.topics.length * 3));
  }

  get totalQuestions() {
    return this._totalQuestions;
  }

  get questionsAnswered() {
    return this.answers.length;
  }

  get currentDifficultyLevel(): Difficulty {
    return this.currentDifficulty;
  }

  get isComplete(): boolean {
    return this.answers.length >= this._totalQuestions;
  }

  getNextQuestion(): Question | null {
    if (this.isComplete) return null;

    // Rotate through topics
    const topic = this.topics[this.topicIndex % this.topics.length];
    this.topicIndex++;

    // Find a question matching current difficulty and topic
    let candidates = questionBank.filter(
      q => q.topic === topic && q.difficulty === this.currentDifficulty && !this.usedQuestionIds.has(q.id)
    );

    // Fallback: any difficulty in same topic
    if (candidates.length === 0) {
      candidates = questionBank.filter(
        q => q.topic === topic && !this.usedQuestionIds.has(q.id)
      );
    }

    // Fallback: any unused question at current difficulty
    if (candidates.length === 0) {
      candidates = questionBank.filter(
        q => q.difficulty === this.currentDifficulty && !this.usedQuestionIds.has(q.id)
      );
    }

    // Last fallback: any unused question
    if (candidates.length === 0) {
      candidates = questionBank.filter(q => !this.usedQuestionIds.has(q.id));
    }

    if (candidates.length === 0) return null;

    const question = candidates[Math.floor(Math.random() * candidates.length)];
    this.usedQuestionIds.add(question.id);
    return question;
  }

  recordAnswer(question: Question, selectedAnswer: number, timeSpent: number): boolean {
    const isCorrect = selectedAnswer === question.correctAnswer;

    this.answers.push({
      questionId: question.id,
      topic: question.topic,
      difficulty: question.difficulty,
      isCorrect,
      timeSpent,
    });

    this.difficultyHistory.push({
      question: this.answers.length,
      difficulty: DIFFICULTY_VALUE[this.currentDifficulty],
    });

    // Adapt difficulty
    if (isCorrect) {
      this.consecutiveCorrect++;
      this.consecutiveWrong = 0;
      if (this.consecutiveCorrect >= 2 && this.currentDifficulty !== 'hard') {
        this.currentDifficulty = this.currentDifficulty === 'easy' ? 'medium' : 'hard';
        this.consecutiveCorrect = 0;
      }
    } else {
      this.consecutiveWrong++;
      this.consecutiveCorrect = 0;
      if (this.consecutiveWrong >= 2 && this.currentDifficulty !== 'easy') {
        this.currentDifficulty = this.currentDifficulty === 'hard' ? 'medium' : 'easy';
        this.consecutiveWrong = 0;
      }
    }

    return isCorrect;
  }

  getResults(): AssessmentResult {
    const correctCount = this.answers.filter(a => a.isCorrect).length;
    const totalTime = this.answers.reduce((sum, a) => sum + a.timeSpent, 0);
    const avgDifficulty = this.answers.reduce((sum, a) => sum + DIFFICULTY_VALUE[a.difficulty], 0) / this.answers.length;

    const topicProfiles: TopicProfile[] = this.topics.map(topic => {
      const topicAnswers = this.answers.filter(a => a.topic === topic);
      const correct = topicAnswers.filter(a => a.isCorrect).length;
      const total = topicAnswers.length;
      const avgDiff = total > 0 ? topicAnswers.reduce((s, a) => s + DIFFICULTY_VALUE[a.difficulty], 0) / total : 1;

      // Mastery considers both accuracy and difficulty level
      let mastery = 0;
      if (total > 0) {
        const accuracy = correct / total;
        mastery = Math.round(accuracy * avgDiff * 33.33);
        mastery = Math.min(100, mastery);
      }

      let strength: TopicProfile['strength'] = 'weak';
      if (mastery >= 80) strength = 'mastered';
      else if (mastery >= 60) strength = 'proficient';
      else if (mastery >= 35) strength = 'developing';

      return {
        topic,
        label: TOPIC_LABELS[topic],
        mastery,
        questionsAnswered: total,
        correctAnswers: correct,
        averageDifficulty: avgDiff,
        strength,
      };
    });

    const overallMastery = Math.round(
      topicProfiles.reduce((sum, tp) => sum + tp.mastery, 0) / topicProfiles.length
    );

    return {
      totalQuestions: this.answers.length,
      correctAnswers: correctCount,
      accuracy: Math.round((correctCount / this.answers.length) * 100),
      averageDifficulty: Math.round(avgDifficulty * 100) / 100,
      totalTime,
      topicProfiles,
      overallMastery,
      difficultyProgression: this.difficultyHistory,
    };
  }
}
