import { Question } from '@/types/assessment';

export const questionBank: Question[] = [
  // ALGEBRA - Easy
  { id: 'alg-e1', topic: 'algebra', difficulty: 'easy', question: 'Solve for x: 2x + 6 = 14', options: ['x = 3', 'x = 4', 'x = 5', 'x = 8'], correctAnswer: 1, explanation: 'Subtract 6 from both sides: 2x = 8, then divide by 2: x = 4.' },
  { id: 'alg-e2', topic: 'algebra', difficulty: 'easy', question: 'Simplify: 3(x + 2)', options: ['3x + 2', '3x + 6', 'x + 6', '3x + 5'], correctAnswer: 1, explanation: 'Distribute 3: 3·x + 3·2 = 3x + 6.' },
  { id: 'alg-e3', topic: 'algebra', difficulty: 'easy', question: 'What is the value of 5² − 3²?', options: ['16', '14', '8', '22'], correctAnswer: 0, explanation: '25 − 9 = 16.' },
  // ALGEBRA - Medium
  { id: 'alg-m1', topic: 'algebra', difficulty: 'medium', question: 'Solve: x² − 5x + 6 = 0', options: ['x = 2, 3', 'x = 1, 6', 'x = −2, −3', 'x = −1, 6'], correctAnswer: 0, explanation: 'Factor: (x−2)(x−3) = 0, so x = 2 or x = 3.' },
  { id: 'alg-m2', topic: 'algebra', difficulty: 'medium', question: 'If f(x) = 2x² + 3x − 5, find f(2)', options: ['9', '7', '11', '5'], correctAnswer: 0, explanation: 'f(2) = 2(4) + 3(2) − 5 = 8 + 6 − 5 = 9.' },
  { id: 'alg-m3', topic: 'algebra', difficulty: 'medium', question: 'Solve the inequality: 3x − 7 > 8', options: ['x > 5', 'x > 3', 'x > 15', 'x < 5'], correctAnswer: 0, explanation: '3x > 15, so x > 5.' },
  // ALGEBRA - Hard
  { id: 'alg-h1', topic: 'algebra', difficulty: 'hard', question: 'Find the sum of roots of 2x³ − 6x² + x − 3 = 0', options: ['3', '−3', '6', '1/2'], correctAnswer: 0, explanation: 'By Vieta\'s formulas, sum of roots = −(−6)/2 = 3.' },
  { id: 'alg-h2', topic: 'algebra', difficulty: 'hard', question: 'Solve: |2x − 3| + |x + 1| = 7 for x > 2', options: ['x = 3', 'x = 4', 'x = 5', 'x = 2.5'], correctAnswer: 0, explanation: 'For x > 2: (2x−3) + (x+1) = 7 → 3x − 2 = 7 → x = 3.' },

  // GEOMETRY - Easy
  { id: 'geo-e1', topic: 'geometry', difficulty: 'easy', question: 'What is the area of a rectangle with length 8 and width 5?', options: ['40', '26', '13', '35'], correctAnswer: 0, explanation: 'Area = length × width = 8 × 5 = 40.' },
  { id: 'geo-e2', topic: 'geometry', difficulty: 'easy', question: 'How many degrees are in a triangle?', options: ['90°', '180°', '360°', '270°'], correctAnswer: 1, explanation: 'The sum of angles in a triangle is always 180°.' },
  { id: 'geo-e3', topic: 'geometry', difficulty: 'easy', question: 'What is the perimeter of a square with side 6?', options: ['24', '36', '12', '18'], correctAnswer: 0, explanation: 'Perimeter = 4 × side = 4 × 6 = 24.' },
  // GEOMETRY - Medium
  { id: 'geo-m1', topic: 'geometry', difficulty: 'medium', question: 'Find the area of a circle with radius 7 (use π ≈ 22/7)', options: ['154', '44', '49', '308'], correctAnswer: 0, explanation: 'A = πr² = (22/7)(49) = 154.' },
  { id: 'geo-m2', topic: 'geometry', difficulty: 'medium', question: 'In a right triangle with legs 5 and 12, find the hypotenuse.', options: ['13', '17', '15', '11'], correctAnswer: 0, explanation: '√(25 + 144) = √169 = 13.' },
  // GEOMETRY - Hard
  { id: 'geo-h1', topic: 'geometry', difficulty: 'hard', question: 'Find the volume of a cone with radius 3 and height 7 (use π ≈ 22/7)', options: ['66', '198', '33', '132'], correctAnswer: 0, explanation: 'V = (1/3)πr²h = (1/3)(22/7)(9)(7) = 66.' },
  { id: 'geo-h2', topic: 'geometry', difficulty: 'hard', question: 'Two similar triangles have areas in ratio 4:9. What is the ratio of their corresponding sides?', options: ['2:3', '4:9', '16:81', '1:2'], correctAnswer: 0, explanation: 'Side ratio = √(area ratio) = √(4/9) = 2/3.' },

  // CALCULUS - Easy
  { id: 'cal-e1', topic: 'calculus', difficulty: 'easy', question: 'Find the derivative of f(x) = 3x²', options: ['6x', '3x', '6x²', '3'], correctAnswer: 0, explanation: 'Using power rule: d/dx(3x²) = 6x.' },
  { id: 'cal-e2', topic: 'calculus', difficulty: 'easy', question: 'What is ∫4 dx?', options: ['4x + C', '4', 'x + C', '2x² + C'], correctAnswer: 0, explanation: 'The integral of a constant is the constant times x, plus C.' },
  // CALCULUS - Medium
  { id: 'cal-m1', topic: 'calculus', difficulty: 'medium', question: 'Find d/dx [sin(x) · x²]', options: ['x²cos(x) + 2x·sin(x)', '2x·cos(x)', 'cos(x)·x²', 'sin(x) + x²'], correctAnswer: 0, explanation: 'Product rule: x²cos(x) + 2x·sin(x).' },
  { id: 'cal-m2', topic: 'calculus', difficulty: 'medium', question: 'Evaluate: ∫₀² (3x²) dx', options: ['8', '12', '6', '4'], correctAnswer: 0, explanation: '[x³]₀² = 8 − 0 = 8.' },
  // CALCULUS - Hard
  { id: 'cal-h1', topic: 'calculus', difficulty: 'hard', question: 'Find the limit: lim(x→0) [sin(3x)/x]', options: ['3', '0', '1', '∞'], correctAnswer: 0, explanation: 'lim sin(3x)/x = 3 · lim sin(3x)/(3x) = 3·1 = 3.' },
  { id: 'cal-h2', topic: 'calculus', difficulty: 'hard', question: 'Find d²y/dx² if y = e^(2x)', options: ['4e^(2x)', '2e^(2x)', 'e^(2x)', '4e^(x)'], correctAnswer: 0, explanation: 'dy/dx = 2e^(2x), d²y/dx² = 4e^(2x).' },

  // STATISTICS - Easy
  { id: 'stat-e1', topic: 'statistics', difficulty: 'easy', question: 'Find the mean of: 4, 8, 6, 10, 2', options: ['6', '8', '5', '7'], correctAnswer: 0, explanation: '(4+8+6+10+2)/5 = 30/5 = 6.' },
  { id: 'stat-e2', topic: 'statistics', difficulty: 'easy', question: 'What is the median of: 3, 7, 1, 9, 5?', options: ['5', '3', '7', '1'], correctAnswer: 0, explanation: 'Sorted: 1,3,5,7,9. Middle value is 5.' },
  // STATISTICS - Medium
  { id: 'stat-m1', topic: 'statistics', difficulty: 'medium', question: 'What is the standard deviation of: 2, 4, 4, 4, 5, 5, 7, 9?', options: ['2', '3', '1.5', '2.5'], correctAnswer: 0, explanation: 'Mean = 5, variance = 4, SD = 2.' },
  { id: 'stat-m2', topic: 'statistics', difficulty: 'medium', question: 'If P(A) = 0.3 and P(B) = 0.5 and A,B are independent, find P(A∩B)', options: ['0.15', '0.80', '0.35', '0.20'], correctAnswer: 0, explanation: 'P(A∩B) = P(A)·P(B) = 0.3·0.5 = 0.15.' },
  // STATISTICS - Hard
  { id: 'stat-h1', topic: 'statistics', difficulty: 'hard', question: 'In a normal distribution, what % of data falls within 2 standard deviations of the mean?', options: ['95.44%', '68.26%', '99.74%', '50%'], correctAnswer: 0, explanation: 'The empirical rule: ~95.44% within 2σ.' },

  // LOGIC - Easy
  { id: 'log-e1', topic: 'logic', difficulty: 'easy', question: 'If all cats are animals, and Whiskers is a cat, what can we conclude?', options: ['Whiskers is an animal', 'All animals are cats', 'Whiskers is not an animal', 'Nothing'], correctAnswer: 0, explanation: 'This is a basic syllogism: if all A are B, and C is A, then C is B.' },
  { id: 'log-e2', topic: 'logic', difficulty: 'easy', question: 'What is the next number: 2, 4, 8, 16, ?', options: ['32', '24', '20', '18'], correctAnswer: 0, explanation: 'Each number is doubled: 16 × 2 = 32.' },
  // LOGIC - Medium
  { id: 'log-m1', topic: 'logic', difficulty: 'medium', question: 'If P → Q is true, and Q is false, what can we conclude about P?', options: ['P is false', 'P is true', 'P could be either', 'Nothing'], correctAnswer: 0, explanation: 'Modus tollens: if P→Q and ¬Q, then ¬P.' },
  { id: 'log-m2', topic: 'logic', difficulty: 'medium', question: 'How many ways can 5 books be arranged on a shelf?', options: ['120', '25', '60', '24'], correctAnswer: 0, explanation: '5! = 5×4×3×2×1 = 120.' },
  // LOGIC - Hard
  { id: 'log-h1', topic: 'logic', difficulty: 'hard', question: 'In how many ways can a committee of 3 be chosen from 8 people?', options: ['56', '336', '24', '40320'], correctAnswer: 0, explanation: 'C(8,3) = 8!/(3!5!) = 56.' },
  { id: 'log-h2', topic: 'logic', difficulty: 'hard', question: 'If the contrapositive of a statement is true, the original statement is:', options: ['True', 'False', 'Uncertain', 'Invalid'], correctAnswer: 0, explanation: 'A statement and its contrapositive are logically equivalent.' },
];
