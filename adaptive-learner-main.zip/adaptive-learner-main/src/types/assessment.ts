export type Difficulty = 'easy' | 'medium' | 'hard';
export type Topic = 'algebra' | 'geometry' | 'calculus' | 'statistics' | 'logic';

export interface Question {
  id: string;
  topic: Topic;
  difficulty: Difficulty;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface AnswerRecord {
  questionId: string;
  topic: Topic;
  difficulty: Difficulty;
  isCorrect: boolean;
  timeSpent: number; // seconds
}

export interface TopicProfile {
  topic: Topic;
  label: string;
  mastery: number; // 0-100
  questionsAnswered: number;
  correctAnswers: number;
  averageDifficulty: number; // 1-3
  strength: 'weak' | 'developing' | 'proficient' | 'mastered';
}

export interface AssessmentResult {
  totalQuestions: number;
  correctAnswers: number;
  accuracy: number;
  averageDifficulty: number;
  totalTime: number;
  topicProfiles: TopicProfile[];
  overallMastery: number;
  difficultyProgression: { question: number; difficulty: number }[];
}

export const TOPIC_LABELS: Record<Topic, string> = {
  algebra: 'Algebra',
  geometry: 'Geometry',
  calculus: 'Calculus',
  statistics: 'Statistics',
  logic: 'Logic & Reasoning',
};

export const DIFFICULTY_LABELS: Record<Difficulty, string> = {
  easy: 'Easy',
  medium: 'Medium',
  hard: 'Hard',
};

export const DIFFICULTY_VALUE: Record<Difficulty, number> = {
  easy: 1,
  medium: 2,
  hard: 3,
};
