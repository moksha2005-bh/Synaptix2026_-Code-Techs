import { useState } from 'react';
import { motion } from 'framer-motion';
import { Topic, TOPIC_LABELS } from '@/types/assessment';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { BookOpen, Brain, ChartBar, Compass, Sigma } from 'lucide-react';

const TOPIC_ICONS: Record<Topic, React.ReactNode> = {
  algebra: <Sigma className="w-6 h-6" />,
  geometry: <Compass className="w-6 h-6" />,
  calculus: <Brain className="w-6 h-6" />,
  statistics: <ChartBar className="w-6 h-6" />,
  logic: <BookOpen className="w-6 h-6" />,
};

const ALL_TOPICS: Topic[] = ['algebra', 'geometry', 'calculus', 'statistics', 'logic'];

interface TopicSelectorProps {
  onStart: (topics: Topic[]) => void;
}

const TopicSelector = ({ onStart }: TopicSelectorProps) => {
  const [selected, setSelected] = useState<Set<Topic>>(new Set(ALL_TOPICS));

  const toggle = (topic: Topic) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(topic) ? next.delete(topic) : next.add(topic);
      return next;
    });
  };

  const toggleAll = () => {
    setSelected(prev => (prev.size === ALL_TOPICS.length ? new Set() : new Set(ALL_TOPICS)));
  };

  const questionCount = Math.max(5, Math.min(15, selected.size * 3));

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-xl"
      >
        <h1 className="text-3xl font-display font-bold text-foreground text-center mb-2">
          Choose Your Topics
        </h1>
        <p className="text-muted-foreground text-center mb-8">
          Select the topics you'd like to be assessed on
        </p>

        {/* Select All */}
        <button
          onClick={toggleAll}
          className="flex items-center gap-2 mb-4 text-sm font-medium text-accent hover:text-accent/80 transition-colors"
        >
          <Checkbox checked={selected.size === ALL_TOPICS.length} />
          <span>Select All</span>
        </button>

        {/* Topic Cards */}
        <div className="space-y-3 mb-8">
          {ALL_TOPICS.map((topic, i) => {
            const isSelected = selected.has(topic);
            return (
              <motion.button
                key={topic}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => toggle(topic)}
                className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl border-2 transition-all duration-200 text-left ${
                  isSelected
                    ? 'border-accent bg-accent/5 shadow-sm'
                    : 'border-border/60 hover:border-accent/30'
                }`}
              >
                <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${
                  isSelected ? 'bg-accent/15 text-accent' : 'bg-secondary text-muted-foreground'
                }`}>
                  {TOPIC_ICONS[topic]}
                </div>
                <span className="font-semibold text-foreground flex-1">{TOPIC_LABELS[topic]}</span>
                <Checkbox checked={isSelected} />
              </motion.button>
            );
          })}
        </div>

        {/* Info + Start */}
        <div className="text-center">
          <p className="text-sm text-muted-foreground mb-4">
            {selected.size > 0
              ? `${questionCount} questions · ${questionCount * 2} min time limit · 30s per question`
              : 'Select at least one topic to continue'}
          </p>
          <Button
            size="lg"
            disabled={selected.size === 0}
            onClick={() => onStart(Array.from(selected))}
            className="bg-gradient-accent text-accent-foreground px-10 py-3 text-base font-semibold rounded-xl shadow-glow hover:opacity-90 transition-opacity"
          >
            Start Assessment
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default TopicSelector;
