import { Difficulty, DIFFICULTY_LABELS } from '@/types/assessment';

interface DifficultyIndicatorProps {
  difficulty: Difficulty;
}

const colorMap: Record<Difficulty, string> = {
  easy: 'bg-difficulty-easy',
  medium: 'bg-difficulty-medium',
  hard: 'bg-difficulty-hard',
};

const textMap: Record<Difficulty, string> = {
  easy: 'text-difficulty-easy',
  medium: 'text-difficulty-medium',
  hard: 'text-difficulty-hard',
};

const DifficultyIndicator = ({ difficulty }: DifficultyIndicatorProps) => {
  return (
    <div className="flex items-center gap-2">
      <div className={`h-2.5 w-2.5 rounded-full ${colorMap[difficulty]}`} />
      <span className={`text-sm font-semibold ${textMap[difficulty]}`}>
        {DIFFICULTY_LABELS[difficulty]}
      </span>
    </div>
  );
};

export default DifficultyIndicator;
