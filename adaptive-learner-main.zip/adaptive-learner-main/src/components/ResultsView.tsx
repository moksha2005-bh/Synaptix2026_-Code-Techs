import { motion } from 'framer-motion';
import { AssessmentResult, TopicProfile } from '@/types/assessment';
import { Award, TrendingUp, Clock, Target, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import MasteryBadge from './MasteryBadge';

interface ResultsViewProps {
  results: AssessmentResult;
  onRetake: () => void;
}

const ResultsView = ({ results, onRetake }: ResultsViewProps) => {
  const radarData = results.topicProfiles.map(tp => ({
    topic: tp.label,
    mastery: tp.mastery,
    fullMark: 100,
  }));

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}m ${s}s`;
  };

  return (
    <div className="min-h-screen px-4 py-12">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-accent mb-4">
            <Award className="w-8 h-8 text-accent-foreground" />
          </div>
          <h1 className="text-4xl font-display font-bold text-foreground mb-2">Your Competency Profile</h1>
          <p className="text-muted-foreground text-lg">Assessment complete — here's your personalized breakdown</p>
        </motion.div>

        {/* Summary cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10"
        >
          {[
            { icon: Target, label: 'Accuracy', value: `${results.accuracy}%` },
            { icon: TrendingUp, label: 'Overall Mastery', value: `${results.overallMastery}%` },
            { icon: Award, label: 'Avg Difficulty', value: results.averageDifficulty.toFixed(1) + '/3' },
            { icon: Clock, label: 'Total Time', value: formatTime(results.totalTime) },
          ].map((stat) => (
            <div key={stat.label} className="bg-card rounded-xl p-5 shadow-card border border-border/50 text-center">
              <stat.icon className="w-5 h-5 text-accent mx-auto mb-2" />
              <p className="text-2xl font-display font-bold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </motion.div>

        {/* Radar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card rounded-2xl p-6 shadow-card border border-border/50 mb-8"
        >
          <h2 className="text-lg font-display font-bold text-foreground mb-4">Skill Radar</h2>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="hsl(var(--border))" />
              <PolarAngleAxis dataKey="topic" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
              <Radar
                name="Mastery"
                dataKey="mastery"
                stroke="hsl(var(--accent))"
                fill="hsl(var(--accent))"
                fillOpacity={0.2}
                strokeWidth={2}
              />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Difficulty Progression */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-2xl p-6 shadow-card border border-border/50 mb-8"
        >
          <h2 className="text-lg font-display font-bold text-foreground mb-4">Difficulty Progression</h2>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={results.difficultyProgression}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="question" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} label={{ value: 'Question', position: 'insideBottom', offset: -5, fill: 'hsl(var(--muted-foreground))' }} />
              <YAxis domain={[0.5, 3.5]} ticks={[1, 2, 3]} tickFormatter={(v) => ['', 'Easy', 'Med', 'Hard'][v]} tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
              <Tooltip
                contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }}
                formatter={(value: number) => [['', 'Easy', 'Medium', 'Hard'][value], 'Difficulty']}
              />
              <Line type="monotone" dataKey="difficulty" stroke="hsl(var(--accent))" strokeWidth={2.5} dot={{ fill: 'hsl(var(--accent))', r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Topic Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-10"
        >
          <h2 className="text-lg font-display font-bold text-foreground mb-4">Topic Breakdown</h2>
          <div className="space-y-3">
            {results.topicProfiles.map((tp) => (
              <TopicRow key={tp.topic} profile={tp} />
            ))}
          </div>
        </motion.div>

        {/* Retake */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center"
        >
          <Button onClick={onRetake} size="lg" variant="outline" className="gap-2">
            <RotateCcw className="w-4 h-4" />
            Retake Assessment
          </Button>
        </motion.div>
      </div>
    </div>
  );
};

const TopicRow = ({ profile }: { profile: TopicProfile }) => {
  return (
    <div className="bg-card rounded-xl p-5 shadow-card border border-border/50 flex items-center gap-4">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-2">
          <h3 className="font-display font-semibold text-foreground">{profile.label}</h3>
          <MasteryBadge strength={profile.strength} />
        </div>
        <div className="flex items-center gap-3">
          <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${profile.mastery}%` }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="h-full bg-gradient-accent rounded-full"
            />
          </div>
          <span className="text-sm font-bold text-foreground w-12 text-right">{profile.mastery}%</span>
        </div>
      </div>
      <div className="text-right text-sm text-muted-foreground">
        <p>{profile.correctAnswers}/{profile.questionsAnswered} correct</p>
      </div>
    </div>
  );
};

export default ResultsView;
