import { TopicProfile } from '@/types/assessment';

const styles: Record<TopicProfile['strength'], { bg: string; text: string; label: string }> = {
  mastered: { bg: 'bg-success/15', text: 'text-success', label: 'Mastered' },
  proficient: { bg: 'bg-info/15', text: 'text-info', label: 'Proficient' },
  developing: { bg: 'bg-warning/15', text: 'text-warning', label: 'Developing' },
  weak: { bg: 'bg-destructive/15', text: 'text-destructive', label: 'Needs Work' },
};

const MasteryBadge = ({ strength }: { strength: TopicProfile['strength'] }) => {
  const s = styles[strength];
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-semibold ${s.bg} ${s.text}`}>
      {s.label}
    </span>
  );
};

export default MasteryBadge;
