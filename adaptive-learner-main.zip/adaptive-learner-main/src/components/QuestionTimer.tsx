import { useEffect, useState } from 'react';

interface QuestionTimerProps {
  duration: number; // seconds
  onExpire: () => void;
  resetKey: string | number; // change to reset
}

const RADIUS = 18;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

const QuestionTimer = ({ duration, onExpire, resetKey }: QuestionTimerProps) => {
  const [remaining, setRemaining] = useState(duration);

  useEffect(() => {
    setRemaining(duration);
  }, [resetKey, duration]);

  useEffect(() => {
    if (remaining <= 0) {
      onExpire();
      return;
    }
    const id = setTimeout(() => setRemaining(r => r - 1), 1000);
    return () => clearTimeout(id);
  }, [remaining, onExpire]);

  const fraction = remaining / duration;
  const offset = CIRCUMFERENCE * (1 - fraction);
  const isWarning = remaining <= 10;
  const isCritical = remaining <= 5;

  const strokeColor = isCritical
    ? 'hsl(var(--destructive))'
    : isWarning
      ? 'hsl(var(--warning))'
      : 'hsl(var(--accent))';

  return (
    <div className="relative flex items-center justify-center w-12 h-12">
      <svg width="48" height="48" viewBox="0 0 48 48" className="-rotate-90">
        <circle
          cx="24" cy="24" r={RADIUS}
          fill="none"
          stroke="hsl(var(--border))"
          strokeWidth="3"
        />
        <circle
          cx="24" cy="24" r={RADIUS}
          fill="none"
          stroke={strokeColor}
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={CIRCUMFERENCE}
          strokeDashoffset={offset}
          className="transition-all duration-1000 ease-linear"
        />
      </svg>
      <span className={`absolute text-xs font-bold ${isCritical ? 'text-destructive' : isWarning ? 'text-warning' : 'text-foreground'}`}>
        {remaining}
      </span>
    </div>
  );
};

export default QuestionTimer;
