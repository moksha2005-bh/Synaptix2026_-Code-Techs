import { motion } from 'framer-motion';
import { Brain, Zap, Target, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface LandingViewProps {
  onStart: () => void;
}

const features = [
  { icon: Zap, title: 'Adaptive Difficulty', desc: 'Questions adjust in real time to your skill level' },
  { icon: Brain, title: 'Smart Analysis', desc: 'AI-driven pattern recognition across topics' },
  { icon: Target, title: 'Precision Testing', desc: 'Pinpoint your exact mastery levels' },
  { icon: BarChart3, title: 'Detailed Profile', desc: 'Comprehensive competency breakdown' },
];

const LandingView = ({ onStart }: LandingViewProps) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: 'easeOut' }}
        className="text-center max-w-2xl mx-auto mb-16"
      >
        <div className="inline-flex items-center gap-2 rounded-full bg-accent/10 px-4 py-1.5 mb-6">
          <div className="h-2 w-2 rounded-full bg-accent animate-pulse-glow" />
          <span className="text-sm font-medium text-accent">Adaptive Assessment</span>
        </div>
        <h1 className="text-5xl md:text-6xl font-bold font-display tracking-tight mb-6">
          <span className="text-gradient-hero">Discover Your</span>
          <br />
          <span className="text-foreground">True Potential</span>
        </h1>
        <p className="text-lg text-muted-foreground max-w-lg mx-auto mb-10 leading-relaxed">
          Take an intelligent assessment that adapts to your performance in real time, 
          revealing precise strengths and areas for growth across key mathematical topics.
        </p>
        <Button
          onClick={onStart}
          size="lg"
          className="bg-gradient-hero text-primary-foreground hover:opacity-90 transition-opacity px-8 py-6 text-lg rounded-xl shadow-glow"
        >
          Begin Assessment
        </Button>
        <p className="text-sm text-muted-foreground mt-4">15 questions · ~10 minutes · No signup required</p>
      </motion.div>

      {/* Features */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.3 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl w-full"
      >
        {features.map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
            className="bg-card rounded-xl p-5 shadow-card border border-border/50 hover:shadow-elevated transition-shadow"
          >
            <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center mb-3">
              <f.icon className="w-5 h-5 text-accent" />
            </div>
            <h3 className="font-display font-semibold text-foreground mb-1">{f.title}</h3>
            <p className="text-sm text-muted-foreground">{f.desc}</p>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
};

export default LandingView;
