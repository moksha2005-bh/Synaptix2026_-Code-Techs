import { useState } from 'react';
import { motion } from 'framer-motion';
import { Question, TOPIC_LABELS } from '@/types/assessment';
import { CheckCircle2, XCircle } from 'lucide-react';

interface QuestionCardProps {
  question: Question;
  onAnswer: (index: number) => void;
  feedback: { isCorrect: boolean; explanation: string } | null;
}

const QuestionCard = ({ question, onAnswer, feedback }: QuestionCardProps) => {
  const [selected, setSelected] = useState<number | null>(null);

  const handleSelect = (index: number) => {
    if (feedback) return;
    setSelected(index);
    onAnswer(index);
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 40 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -40 }}
      transition={{ duration: 0.35 }}
      className="w-full max-w-2xl"
    >
      <div className="bg-card rounded-2xl shadow-elevated border border-border/50 p-8">
        <span className="inline-block text-xs font-semibold uppercase tracking-wider text-accent mb-4">
          {TOPIC_LABELS[question.topic]}
        </span>
        <h2 className="text-xl md:text-2xl font-display font-bold text-foreground mb-8 leading-snug">
          {question.question}
        </h2>

        <div className="space-y-3">
          {question.options.map((option, i) => {
            let borderClass = 'border-border/60 hover:border-accent/40 hover:bg-accent/5';
            if (feedback && selected === i) {
              borderClass = feedback.isCorrect
                ? 'border-success bg-success/5'
                : 'border-destructive bg-destructive/5';
            }
            if (feedback && i === question.correctAnswer && !feedback.isCorrect) {
              borderClass = 'border-success bg-success/5';
            }

            return (
              <button
                key={i}
                onClick={() => handleSelect(i)}
                disabled={!!feedback}
                className={`w-full text-left px-5 py-4 rounded-xl border-2 transition-all duration-200 ${borderClass} ${
                  !feedback ? 'cursor-pointer' : 'cursor-default'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="flex-shrink-0 w-8 h-8 rounded-lg bg-secondary flex items-center justify-center text-sm font-semibold text-foreground">
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="text-foreground font-medium">{option}</span>
                  {feedback && i === question.correctAnswer && (
                    <CheckCircle2 className="w-5 h-5 text-success ml-auto flex-shrink-0" />
                  )}
                  {feedback && selected === i && !feedback.isCorrect && (
                    <XCircle className="w-5 h-5 text-destructive ml-auto flex-shrink-0" />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Feedback */}
        {feedback && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`mt-6 p-4 rounded-xl ${
              feedback.isCorrect ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'
            }`}
          >
            <p className="font-semibold mb-1">{feedback.isCorrect ? 'Correct!' : 'Incorrect'}</p>
            <p className="text-sm opacity-80">{feedback.explanation}</p>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

export default QuestionCard;
