import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Question, Difficulty, Topic } from '@/types/assessment';
import { AdaptiveEngine } from '@/lib/adaptiveEngine';
import QuestionCard from './QuestionCard';
import DifficultyIndicator from './DifficultyIndicator';
import QuestionTimer from './QuestionTimer';
import { Clock } from 'lucide-react';

interface QuizViewProps {
  selectedTopics: Topic[];
  onComplete: (engine: AdaptiveEngine) => void;
}

const QuizView = ({ selectedTopics, onComplete }: QuizViewProps) => {
  const engineRef = useRef(new AdaptiveEngine(selectedTopics));
  const engine = engineRef.current;
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [questionNumber, setQuestionNumber] = useState(0);
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; explanation: string } | null>(null);
  const [startTime, setStartTime] = useState(Date.now());
  const [overallElapsed, setOverallElapsed] = useState(0);
  const overallTimerRef = useRef<ReturnType<typeof setInterval>>();
  const overallStartRef = useRef(Date.now());
  const completedRef = useRef(false);

  const overallLimit = engine.totalQuestions * 120; // 2 min per question

  const completeAssessment = useCallback(() => {
    if (completedRef.current) return;
    completedRef.current = true;
    clearInterval(overallTimerRef.current);
    onComplete(engine);
  }, [engine, onComplete]);

  // Overall timer
  useEffect(() => {
    overallStartRef.current = Date.now();
    overallTimerRef.current = setInterval(() => {
      const elapsed = Math.round((Date.now() - overallStartRef.current) / 1000);
      setOverallElapsed(elapsed);
      if (elapsed >= overallLimit) {
        completeAssessment();
      }
    }, 1000);
    return () => clearInterval(overallTimerRef.current);
  }, [overallLimit, completeAssessment]);

  const loadNext = useCallback(() => {
    const q = engine.getNextQuestion();
    if (q) {
      setCurrentQuestion(q);
      setQuestionNumber(engine.questionsAnswered + 1);
      setDifficulty(engine.currentDifficultyLevel);
      setFeedback(null);
      setStartTime(Date.now());
    }
  }, [engine]);

  useEffect(() => {
    loadNext();
  }, [loadNext]);

  const handleAnswer = useCallback((selectedIndex: number) => {
    if (!currentQuestion || feedback) return;
    const timeSpent = Math.round((Date.now() - startTime) / 1000);
    const isCorrect = engine.recordAnswer(currentQuestion, selectedIndex, timeSpent);
    setFeedback({ isCorrect, explanation: currentQuestion.explanation });

    setTimeout(() => {
      if (engine.isComplete) {
        completeAssessment();
      } else {
        loadNext();
      }
    }, 2000);
  }, [currentQuestion, feedback, startTime, engine, loadNext, completeAssessment]);

  const handleTimerExpire = useCallback(() => {
    if (!currentQuestion || feedback) return;
    // Auto-submit as wrong (use -1 as invalid index)
    const timeSpent = 30;
    engine.recordAnswer(currentQuestion, -1, timeSpent);
    setFeedback({ isCorrect: false, explanation: currentQuestion.explanation });

    setTimeout(() => {
      if (engine.isComplete) {
        completeAssessment();
      } else {
        loadNext();
      }
    }, 2000);
  }, [currentQuestion, feedback, engine, loadNext, completeAssessment]);

  if (!currentQuestion) return null;

  const progress = (engine.questionsAnswered / engine.totalQuestions) * 100;
  const remainingOverall = Math.max(0, overallLimit - overallElapsed);
  const overallMin = Math.floor(remainingOverall / 60);
  const overallSec = remainingOverall % 60;

  return (
    <div className="min-h-screen flex flex-col px-4 py-8">
      {/* Top bar */}
      <div className="max-w-2xl w-full mx-auto mb-8">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-medium text-muted-foreground">
            Question {questionNumber} of {engine.totalQuestions}
          </span>
          <div className="flex items-center gap-4">
            {/* Overall timer */}
            <div className={`flex items-center gap-1.5 text-sm font-medium ${remainingOverall <= 60 ? 'text-destructive' : 'text-muted-foreground'}`}>
              <Clock className="w-4 h-4" />
              <span>{String(overallMin).padStart(2, '0')}:{String(overallSec).padStart(2, '0')}</span>
            </div>
            <DifficultyIndicator difficulty={difficulty} />
            {/* Per-question timer */}
            <QuestionTimer
              duration={30}
              onExpire={handleTimerExpire}
              resetKey={currentQuestion.id}
            />
          </div>
        </div>
        {/* Progress bar */}
        <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-accent rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="flex-1 flex items-start justify-center pt-4">
        <AnimatePresence mode="wait">
          <QuestionCard
            key={currentQuestion.id}
            question={currentQuestion}
            onAnswer={handleAnswer}
            feedback={feedback}
          />
        </AnimatePresence>
      </div>
    </div>
  );
};

export default QuizView;
