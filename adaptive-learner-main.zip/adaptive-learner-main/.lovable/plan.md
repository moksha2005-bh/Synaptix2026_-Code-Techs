

## Plan: Add Per-Question Timer, Overall Time Limit, and Topic Selection

### 1. Add Topic Selection Screen
- Create `src/components/TopicSelector.tsx` — a new screen between landing and quiz
- Display all 5 topics as toggleable cards with checkboxes
- Include a "Select All" option (default state)
- Show question count estimate based on selected topics
- "Start Assessment" button (disabled if no topics selected)
- Update `Index.tsx` to add a `'topic-select'` phase between landing and quiz

### 2. Update Adaptive Engine for Topic Filtering
- Add a `selectedTopics` parameter to `AdaptiveEngine` constructor
- Filter `this.topics` to only include selected topics
- Adjust `TOTAL_QUESTIONS` dynamically: 3 questions per selected topic (min 5, max 15)
- Update `getNextQuestion()` to only pull from selected topics

### 3. Add Per-Question Timer (30 seconds)
- Create `src/components/QuestionTimer.tsx` — circular countdown timer component
- 30-second countdown per question with animated ring
- Visual warning state (color change) when under 10 seconds
- Auto-submit as incorrect when timer expires
- Display in `QuestionCard` or `QuizView` top bar

### 4. Add Overall Assessment Timer
- Display total elapsed time in the `QuizView` top bar (MM:SS format)
- Set overall time limit based on question count (2 minutes per question)
- Auto-complete assessment when overall timer expires
- Pass remaining questions as unanswered to results

### 5. Wire Everything Together in QuizView
- Accept `selectedTopics` prop from `Index.tsx`
- Pass to `AdaptiveEngine` constructor
- Reset per-question timer on each new question
- Handle both per-question timeout and overall timeout callbacks

### Files to create:
- `src/components/TopicSelector.tsx`
- `src/components/QuestionTimer.tsx`

### Files to modify:
- `src/pages/Index.tsx` — add topic-select phase, pass selected topics
- `src/lib/adaptiveEngine.ts` — accept selected topics, dynamic question count
- `src/components/QuizView.tsx` — integrate both timers, accept selectedTopics prop
- `src/types/assessment.ts` — no changes needed (Topic type already exists)

